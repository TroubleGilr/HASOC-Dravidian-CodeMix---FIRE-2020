import pandas as pd
import csv
import re
import io
import string
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem.snowball import SnowballStemmer
import nltk
nltk.download("stopwords")
nltk.download('punkt')
snowBallStemmer = SnowballStemmer("english")
stop_words = set(stopwords.words('english'))


name = "ValidationV1"


d1 = pd.read_csv('/content/'+name+'.tsv', sep="\t", header=None )
uid = list(d1[0])
sentiment = list(d1[2])
d1 = d1[1]
d1 = list(d1)
for i in range(len(d1)):
  if type(d1[i]) == float:
    d1[i] = " "



print(len(uid))
print(len(sentiment))


hinstopwords = pd.read_csv('/content/hin.txt', sep="\t", header=None )
hinstopwords = list(hinstopwords[0])[:1000]



def Hrmvsw(example_sent):
  word_tokens = word_tokenize(example_sent)
  filtered_sentence = [w for w in word_tokens if not w in hinstopwords]
  filtered_sentence = []
  for w in word_tokens:
    if w not in stop_words:
      filtered_sentence.append(w)
  return(' '.join(filtered_sentence))




XX=[]
for i in range(len(d1)):
  XX.append(Hrmvsw(d1[i]))




with open("/content/"+name[:-2]+"V2.tsv", 'wt',encoding="utf-8") as out_file:
    tsv_writer = csv.writer(out_file, delimiter='\t')
    for k in range(len(XX)):
        f=[]
        f.append(uid[k])
        f.append(XX[k])
        f.append(sentiment[k])
        tsv_writer.writerow(f)
