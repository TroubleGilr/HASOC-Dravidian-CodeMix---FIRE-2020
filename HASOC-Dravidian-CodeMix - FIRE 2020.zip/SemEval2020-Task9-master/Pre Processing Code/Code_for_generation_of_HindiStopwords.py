import pandas as pd
import csv
import re
import io
import string

d1 = pd.read_csv('/content/TrainV1.tsv', sep="\t", header=None )
d2 = pd.read_csv('/content/ValidationV1.tsv', sep="\t", header=None )

d1=d1[1]
d1=list(d1)
for i in range(len(d1)):
  if type(d1[i])==float:
    d1[i]=" "


d2=d2[1]
d2=list(d2)
for i in range(len(d2)):
  if type(d2[i])==float:
    d2[i]=" "

d3 = d1 + d2

len(d3) == len(d1) + len(d2)



h=""
for i in range(len(d3)):
  h=h+d3[i]
h
l=[]
l=h.split(' ')
wordfreq=[l.count(p) for p in l]
V=dict(zip(l,wordfreq))


V={k: v for k, v in sorted(V.items(), key=lambda item: item[1],reverse=True)}

v1 = V.keys()
v1 = list(v1)

v1
#print(v1)

with open("/content/hin.txt", 'wt',encoding="utf-8") as out_file:
    tsv_writer = csv.writer(out_file, delimiter='\t')
    for k in range(len(v1)):
        f=[]
        f.append(v1[k])
        tsv_writer.writerow(f)


