import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
import pandas as pd
import csv
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras import Sequential
from tensorflow.keras.layers import LSTM, Dropout, Dense, Embedding ,Bidirectional
from sklearn.model_selection import train_test_split
import torch
from sklearn.model_selection import train_test_split


d = pd.read_csv('E:/复现/SemEval2020-Task9-master/Fully Processed Datasets/FinalTrainingOnly.tsv', sep="\t", header=None )

x=d[1]
y=d[2]
y=list(y)
x=list(x)

for i in range(len(x)):
  if type(x[i])==float:
    x[i]=" "
    y[i]= 1

y=np.array(y)
print('y',y)


v = pd.read_csv('E:/复现/SemEval2020-Task9-master/Fully Processed Datasets/ValidationOnly.tsv', sep="\t", header=None )

vx=v[1]
vy=v[2]
vy=list(vy)
vx=list(vx)

for i in range(len(vx)):
  if type(vx[i])==float:
    vx[i]=" "
    vy[i]= 1

vy=np.array(vy)


t = pd.read_csv('E:/复现/SemEval2020-Task9-master/Fully Processed Datasets/FinalTest.tsv', sep="\t", header=None )
tx=list(t[1])
for i in range(len(tx)):
  if type(tx[i])==float:
    tx[i]=" "


ty = pd.read_csv('E:/复现/SemEval2020-Task9-master/Fully Processed Datasets/Ty.txt', sep=",", header=None )
sentiment = []
for i in range(len(ty)):
    if ty[1][i]=='negative':
        sentiment.append(0)
    elif ty[1][i]=='neutral':
        sentiment.append(1)
    elif ty[1][i]=='positive':
        sentiment.append(2)

ty = np.array(sentiment)


tokenizer = Tokenizer(num_words=2500,split=' ')
tokenizer.fit_on_texts(x)

X= tokenizer.texts_to_sequences(x)
X = pad_sequences(X,maxlen=50)

VX= tokenizer.texts_to_sequences(vx)
VX = pad_sequences(VX,maxlen=50)


TX = tokenizer.texts_to_sequences(tx)
TX = pad_sequences(TX,maxlen=50)


vocab_size = 20000
embed_size = 128
epochs = 200


# Model no 2

ip = tf.keras.Input(shape=(X.shape[1]))
x = Embedding(vocab_size, embed_size,trainable=True)(ip)
x = tf.keras.layers.Conv1D(64, kernel_size=3, padding='valid', kernel_initializer='glorot_uniform')(x)
x = tf.keras.layers.GlobalMaxPool1D()(x)
x = tf.reshape(x,(-1,1,64))
x = LSTM(64,activation='tanh', dropout=0.15, recurrent_dropout=0.15)(x)
x = Dense(3, activation='softmax')(x)
model = tf.keras.Model(inputs=ip, outputs=x)
model.compile(loss='sparse_categorical_crossentropy', optimizer=tf.keras.optimizers.Adam(learning_rate=0.01, beta_1=0.9, beta_2=0.999, epsilon=1e-07), metrics=['accuracy'])
history = model.fit(X, y, epochs=epochs, batch_size=128,verbose=2,validation_data=(VX,vy))




a = model.predict(VX)
a = np.reshape(a,(3000,3))
a = np.array(a)
a = np.argmax(a,axis=1)



for i in range(len(a)):
  print(str(a[i])+"     "+str(vy[i]))


val_loss, val_acc = model.evaluate(VX,vy)
print("validation accuracy = " + str(val_acc) )


test_loss, test_acc = model.evaluate(TX,ty)
print("Test accuracy = " + str(test_acc) )

from sklearn.metrics import classification_report
y_true = ty
y_pred = a
target_names = ['class 0', 'class 1','class 2']
print(classification_report(y_true, y_pred, target_names=target_names))

#图
acc = history.history['acc']
val_acc = history.history['val_acc']
loss=history.history['loss']
val_loss=history.history['val_loss']
epochs_range = range(epochs)
plt.figure(figsize=(8, 8))
plt.plot(epochs_range, acc, label='Training Accuracy')
plt.plot(epochs_range, val_acc, label='Validation Accuracy')
plt.grid()
plt.legend(loc='lower right')
plt.title('Training and Validation Accuracy')
plt.show()


#图
epochs_range = range(epochs)
plt.figure(figsize=(8, 8))
plt.plot(epochs_range, loss, label='Training Loss')
plt.plot(epochs_range, val_loss, label='Validation Loss')
plt.grid()
plt.legend(loc='lower right')
plt.title('Training and Validation Losses')
plt.show()

#    precision    recall  f1-score   support
#
#      class 0       0.29      0.28      0.29       900
#      class 1       0.36      0.39      0.37      1100
#      class 2       0.34      0.32      0.33      1000
#
#     accuracy                           0.33      3000
#    macro avg       0.33      0.33      0.33      3000
# weighted avg       0.33      0.33      0.33      3000