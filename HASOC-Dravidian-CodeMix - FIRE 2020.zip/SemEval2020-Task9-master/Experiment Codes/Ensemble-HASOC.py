#
# !pip install tensorflow-gpu
# !unzip /content/ds.zip

import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
import pandas as pd
import csv
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras import Sequential
from tensorflow.keras.layers import LSTM, Dropout, Dense, Embedding ,Bidirectional
from sklearn.model_selection import train_test_split
import torch
from sklearn.metrics import accuracy_score
#训练集
d = pd.read_csv('C:/Users/dkj/Desktop/数据/tamil_train1.tsv', sep="\t", header=None )

x=d[1]#text
y=d[2]#lable
y=list(y)
x=list(x)

for i in range(len(x)):
  if type(x[i])==float:
    x[i]=" "
    y[i]= 1

y=np.array(y)
#验证集
v = pd.read_csv('C:/Users/dkj/Desktop/数据/tamil_dev1.tsv', sep="\t", header=None )

vx=v[1]
vy=v[2]
vy=list(vy)
vx=list(vx)

for i in range(len(vx)):
  if type(vx[i])==float:
    vx[i]=" "
    vy[i]= 1

vy=np.array(vy)

#测试集 无标签
t = pd.read_csv('C:/Users/dkj/Desktop/数据/tamil_test - tamil_test.tsv', sep="\t", header=None )
tx=list(t[1])
print('l',len(tx))
# i=5000
# for m in range(len(tx)):
#   print('ss',str(i)+'\t'+tx[m]+'\n')
#   i+=1
for i in range(len(tx)):
  if type(tx[i])==float:
    tx[i]=" "

#测试集标签
ty = pd.read_csv('C:/Users/dkj/Desktop/数据/Ta-test假标签.csv', sep=",", header=None )
sentiment = []
for i in range(len(ty)):
    if ty[1][i]=='Negative':
        sentiment.append(0)
    elif ty[1][i]=='not-Tamil':
        sentiment.append(1)
    elif ty[1][i]=='Positive':
        sentiment.append(2)
    elif ty[1][i]=='unknown_state':
        sentiment.append(3)
    elif ty[1][i]=='Mixed_feelings':
        sentiment.append(4)

    print('====',len(sentiment))


ty = np.array(sentiment)

tokenizer = Tokenizer(num_words=2500,split=' ')
tokenizer.fit_on_texts(x)

X= tokenizer.texts_to_sequences(x)
X = pad_sequences(X,maxlen=50)

VX= tokenizer.texts_to_sequences(vx)
VX = pad_sequences(VX,maxlen=50)


TX = tokenizer.texts_to_sequences(tx)
TX = pad_sequences(TX,maxlen=50)



vocab_size = 20000
embed_size = 128


# Model no 1

ip = tf.keras.Input(shape=(X.shape[1]))
em = Embedding(vocab_size, embed_size,trainable=True)(ip)
x = Bidirectional(LSTM(128,activation='tanh', return_sequences=True, dropout=0.15, recurrent_dropout=0.15))(em) # Dimn shd be (None,200,128)
x = tf.keras.layers.Conv1D(64, kernel_size=3, padding='valid', kernel_initializer='glorot_uniform')(x)
avg_pool = tf.keras.layers.GlobalAveragePooling1D()(x)
max_pool = tf.keras.layers.GlobalMaxPool1D()(x)
x = tf.keras.layers.concatenate([avg_pool, max_pool])
x = Dense(5, activation='softmax')(x)
bi = tf.keras.Model(inputs = ip , outputs = x)
bi.compile(loss='sparse_categorical_crossentropy', optimizer=tf.keras.optimizers.Adam(learning_rate=0.01, beta_1=0.9, beta_2=0.999, epsilon=1e-07), metrics=['accuracy'])
# tf.keras.utils.plot_model(bi, 'my_first_model.png')
#history1 = bi.fit(X, y, epochs=7, batch_size=128,verbose=2,validation_data=(VX,vy))
history1 = bi.fit(X, y, epochs=7, batch_size=128,verbose=2,validation_data=(VX,vy))


test_loss, test_acc = bi.evaluate(TX,ty)
print("modle 1，Test accuracy of BiLSTM model = " + str(test_acc) )

# Model no 2

ip = tf.keras.Input(shape=(X.shape[1]))
x = Embedding(vocab_size, embed_size,trainable=True)(ip)
x = tf.keras.layers.Conv1D(64, kernel_size=3, padding='valid', kernel_initializer='glorot_uniform')(x)
x = tf.keras.layers.GlobalMaxPool1D()(x)
x = tf.reshape(x,(-1,1,64))
x = LSTM(64,activation='tanh', dropout=0.15, recurrent_dropout=0.15)(x)
x = Dense(5, activation='softmax')(x)
cl = tf.keras.Model(inputs=ip, outputs=x)
cl.compile(loss='sparse_categorical_crossentropy', optimizer=tf.keras.optimizers.Adam(learning_rate=0.01, beta_1=0.9, beta_2=0.999, epsilon=1e-07), metrics=['accuracy'])
history = cl.fit(X, y, epochs=5, batch_size=128,verbose=2,validation_data=(VX,vy))


test_loss, test_acc = cl.evaluate(TX,ty)
print("model2,Test accuracy = " + str(test_acc) )


# Model no 3

model = Sequential()
model.add(Embedding(vocab_size, embed_size, input_shape = (X.shape[1],)))
model.add(LSTM(units=264, activation='tanh'))
model.add(Dense(units=64,activation='tanh'))
model.add(Dropout(0.5))
model.add(Dense(units=5, activation='softmax'))

model.compile(optimizer='adam', loss="sparse_categorical_crossentropy", metrics = ['accuracy'])
history = model.fit(X, y, epochs=6, batch_size=128,verbose=2,validation_data=(VX,vy))



test_loss, test_acc = model.evaluate(TX,ty)
print("model3 LSTM Test accuracy = " + str(test_acc) )


# Model no 4

ip = tf.keras.Input(shape=(X.shape[1]))
b = Embedding(vocab_size, embed_size,trainable=True)(ip)
c1 = tf.keras.layers.Conv1D(64, kernel_size=3, padding='valid', kernel_initializer='glorot_uniform')(b)
c2 = tf.keras.layers.Conv1D(64, kernel_size=4, padding='valid', kernel_initializer='glorot_uniform')(b)
c3 = tf.keras.layers.Conv1D(64, kernel_size=5, padding='valid', kernel_initializer='glorot_uniform')(b)
x = tf.keras.layers.concatenate([c1, c2, c3],axis=1)
x = tf.keras.layers.GlobalMaxPool1D()(x)
x = tf.reshape(x,(-1,1,64))
x = Dense(64,activation='tanh')(x)
x = Dense(5, activation='softmax')(x)
cnn = tf.keras.Model(inputs=ip, outputs=x)
cnn.compile(loss='sparse_categorical_crossentropy', optimizer=tf.keras.optimizers.Adam(learning_rate=0.01, beta_1=0.9, beta_2=0.999, epsilon=1e-07), metrics=['accuracy'])
cnn.summary()
history = cnn.fit(X, y, epochs=4, batch_size=128,verbose=2,validation_data=(VX,vy))




test_loss, test_acc = cnn.evaluate(TX,ty)
print("model4， Test accuracy = " + str(test_acc) )




x1 = bi.predict(TX)
x2 = cl.predict(TX)
x3 = model.predict(TX)
x4 = cnn.predict(TX)


x5 = bi.predict(VX)
x6 = cl.predict(VX)
x7 = model.predict(VX)
x8 = cnn.predict(VX)


x4=np.reshape(x4,(3149,5))

x8=np.reshape(x4,(3149,5))


a=[]
for i in range(len(x1)):
  b=[]
  for j in range(len(x1[i])):
    z = max(x1[i][j],x2[i][j],x3[i][j],x4[i][j] )
    b.append(z)
  a.append(b)
  b=[]

#保存测试标签
str1=' '


c=[]
for i in range(len(x5)):
  d=[]
  for j in range(len(x5[i])):
    z = max(x5[i][j],x6[i][j],x7[i][j],x8[i][j] )
    d.append(z)
  c.append(d)
  d=[]


a=np.array(a)
a=np.argmax(a,axis=1)


c=np.array(c)
c=np.argmax(c,axis=1)

val_acc = accuracy_score(vy,c)
print("Validation accuracy = " + str(val_acc) )

test_acc = accuracy_score(ty,a)#ty真实标签 ，a为预测
print("Test accuracy = " + str(test_acc) )

from sklearn.metrics import classification_report
y_true = ty
y_pred = a
#target_names = ['Off', 'Not']
target_names = ['Negative', 'not-Tamil', 'Positive', 'unknown_state', 'Mixed_feelings']
print(classification_report(y_true, y_pred, target_names=target_names))

print('a',a)

fp = open('C:/Users/dkj/Desktop/数据/pred/pred4.csv','a',encoding='utf-8')
#print(len(a))
for k in a:
  #print('k',k)
  if k ==0:
    str1='Negative'+'\n'
  elif k==1:
    str1='not-Tamil'+'\n'
  elif k==2:
    str1='Positive'+'\n'
  elif k==3:
    str1='unknown_state'+'\n'
  elif k==4:
    str1='Mixed_feelings'+'\n'
  fp.write(str1)
